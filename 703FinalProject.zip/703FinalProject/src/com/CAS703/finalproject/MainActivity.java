package com.CAS703.finalproject;

import java.math.BigDecimal;

import com.CAS703.finalproject.R;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener{

	private final int SAMPLING_RATE = 50;//Hz
	private Button mStartButton, mResetButton;
	private TextView mStepNumber, mMoveLength,mSpeed;
	private SensorManager mSensorManager;
	private Sensor mAccelerometer;
	private int mSensorSamplingRate = 1000000/SAMPLING_RATE;//SensorManager.SENSOR_DELAY_GAME
	private boolean isStarted = false;
	private StepCount stepCount;
	private int mWalkTime=0;
	private double speed=0;
	Handler handler = new Handler();
	Runnable runnable = new Runnable() {
		@Override
		public void run() {
			mWalkTime++;
			speed=stepCount.getMoveLength()/mWalkTime;
			BigDecimal bd=new BigDecimal(speed);   
	    	bd = bd.setScale(2,BigDecimal.ROUND_HALF_UP);
			mSpeed.setText("" + bd);
			handler.postDelayed(this, 1000);
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		// Initialize the views
		mStepNumber=(TextView) findViewById(R.id.stepNumber);
		mMoveLength=(TextView) findViewById(R.id.moveLength);
		mSpeed=(TextView) findViewById(R.id.speed);
		// views if the sensor is not available
		mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		//StepCount
		stepCount=new StepCount();
		// get sensors
		if ((mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)) == null) 
		{
			 AlertDialog.Builder builder = new AlertDialog.Builder(this);
			 builder.setMessage("The Accelerometer Sensor is unusable!");
			 builder.setTitle("Alert");
			 builder.setPositiveButton("Got it!", new DialogInterface.OnClickListener() {
				 public void onClick(DialogInterface dialog, int id) { 
					 mStartButton.setEnabled(false);
		             dialog.dismiss();  
		         }
			 });
			 builder.create().show();
		}

		// Initialize the buttons
		mStartButton = (Button) findViewById(R.id.buttonStart);
		mStartButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!isStarted) {
					mStartButton.setText("Stop");
					startSensors();
					isStarted = true;				
				} else {
					mStartButton.setText("Start");
					stopAll();
					isStarted = false;
				}
			}
		});
		mResetButton = (Button) findViewById(R.id.buttonReset);
		mResetButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				resetAll();
			}
		});
	}
	void startSensors() {
		// register the listener for accelerometer
		mSensorManager.registerListener(this, mAccelerometer,mSensorSamplingRate);
		//start timing
		handler.postDelayed(runnable, 1000);
		//Unable Reset Button
		mResetButton.setEnabled(false);
	}
	//Upon stopping the sensors, 
	void stopAll() {
		mResetButton.setEnabled(true);
		//unregister the sensor listener if exists
		mSensorManager.unregisterListener(this);
		//stop timing
		handler.removeCallbacks(runnable);
	}
	void resetAll() {
		mStepNumber.setText("0");
		mMoveLength.setText("0");
		mSpeed.setText("0");
		stepCount.setStepCount(0);
		stepCount.setMoveLength(0);
		mWalkTime=0;
		speed=0;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onAccuracyChanged(Sensor arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}
	
	// Handling sensor reading changes
	@Override
	public void onSensorChanged(SensorEvent event) {
		SensorReading acc;
		if (event.sensor == mAccelerometer) {
			acc=new SensorReading("acc",event.timestamp,event.values);
			stepCount.countSteps(acc);
			mStepNumber.setText(String.valueOf(stepCount.getStepCount()));
			BigDecimal bd=new BigDecimal(stepCount.getMoveLength());   
	    	bd = bd.setScale(2,BigDecimal.ROUND_HALF_UP);
			mMoveLength.setText(String.valueOf(bd));
	    }
	}
}

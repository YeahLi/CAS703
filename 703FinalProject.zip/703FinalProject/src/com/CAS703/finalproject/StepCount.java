package com.CAS703.finalproject;

public class StepCount {
	private boolean mInitialized=false;
	private boolean climbing = true, descending = false;
	private double mLastX, mLastY, mLastZ;
	private final float NOISE = (float) 2;
	private int stepCount = 0, peakCount = 0, valleyCount = 0;
	private double lastReading = Double.MIN_VALUE, largestReading = 0.0;
	private Tools tools=new Tools();
	LowPassFIR lowPassFIR_filter= new LowPassFIR(0.09);
	LowPassFIR lowPassFIR_integrate= new LowPassFIR(0.09);
    WeibergSL weibergSL=new WeibergSL();
    private double moveLength=0;

	//thresholds
	private final double Peak_TH = 0.0;
	private final double Interval_TH = 0.16;//distance between peak and valley
	private final double PeaksTimeInterval_TH=50000000.0;//100000000.0;
	
	private long lastPeakTime = 0l;
	private double lastPeakValue = 0.0;
	private double lastValleyValue = 0.0;
	
	final double alpha = 0.8;		// Constant for our filter below
	
	public void countSteps(SensorReading acc){
		double x = acc.values[0];
    	double y = acc.values[1];
    	double z = acc.values[2];
    	
    	weibergSL.StepLength(x, y, z);//calculate StepLength
    	
    	double[] gravity = {0,0,0};
    	// Isolate the force of gravity with low-pass filter.
    	gravity[0] = alpha * gravity[0] + (1 - alpha) * x;
    	gravity[1] = alpha * gravity[1] + (1 - alpha) * y;
    	gravity[2] = alpha * gravity[2] + (1 - alpha) * z;
    	// Remove gravity contribution with high-pass filter
    	x = x - gravity[0];
    	y = y - gravity[1];
    	z = z - gravity[2];
    	
		if (!mInitialized){
    		// Sensor is used for the first time, initialize the last read values
    		mLastX = x;
    		mLastY = y;
    		mLastZ = z;
    		mInitialized = true;
    	} else {
    		// Sensor already initialized, and we have previously read values.
    		// Take difference of past and current values and decide which axis
    		// acceleration was detected on by comparing values
    		double deltaX = Math.abs(mLastX - x);
    		double deltaY = Math.abs(mLastY - y);
    		double deltaZ = Math.abs(mLastZ - z);
    		
    		if (deltaX < NOISE)
    			deltaX = (float) 0.0;
    		if (deltaY < NOISE)
    			deltaY = (float) 0.0;
    		if (deltaZ < NOISE)
    			deltaZ = (float) 0.0;
    		
    		double norm=tools.norm(deltaX, deltaY, deltaZ);
    		double filter=lowPassFIR_filter.transform(norm);
    		double pow=Math.pow(filter, 2);
    		double currentReading=lowPassFIR_integrate.integrate(pow);   		
    		long currentTime=acc.timestamp;
    		
    		if (largestReading < currentReading){
    			largestReading = currentReading;
    		}
    		if(climbing && (lastReading > currentReading)){
    			peakCount++;
    			if(lastReading > Peak_TH 
        		   && ((currentTime - lastPeakTime) > PeaksTimeInterval_TH)//set the threshold of interval of peaks' timestamps
        		   && (lastReading - lastValleyValue) > Interval_TH) //set the threshold of interval between peak and valley
        		{
        			stepCount++;
        			moveLength=moveLength+weibergSL.getSL();
        		}
        		climbing = false;
        		descending = true;
        		lastPeakTime = currentTime;
        		lastPeakValue = lastReading;
    		}
    		if(descending && lastReading < currentReading){
    			climbing = true;
    			descending = false;
    			valleyCount++;
    			lastValleyValue = lastReading;
    		}
    		lastReading = currentReading;
    	}
	}
	public int getStepCount() {
		return stepCount;
	}
	public void setStepCount(int stepCount) {
		this.stepCount = stepCount;
	}
	public double getMoveLength() {
		return moveLength;
	}
	public void setMoveLength(double moveLength) {
		this.moveLength = moveLength;
	}
}

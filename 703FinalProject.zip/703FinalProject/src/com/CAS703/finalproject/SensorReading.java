package com.CAS703.finalproject;

public class SensorReading {
	String type;
	long timestamp;
	public float values[];
    public SensorReading(String t, long time, float v[]) {
		type = new String(t.toLowerCase());
		timestamp = time;
		values = v.clone();
	}
}

package com.CAS703.finalproject;

public class WeibergSL {
	private Tools tool=new Tools();
	private double SL=0;
	final double alpha = 0.3;		// Constant for our filter below
	private double normFilter=0;
	private double output=0;
	private boolean initialed=false;
	private int times=0;
	private double window[]=new double[16];
	private double max=0,min=0;
    final double K=0.364;//According to experiments
    
	public WeibergSL()
	{
		for(int i=0;i<window.length;i++)
		{
			window[i]=0;
		}
	}
	public void StepLength(double accX, double accY, double accZ){
		double x = accX;
    	double y = accY;
    	double z = accZ;
    	double[] gravity = {0,0,0}; 
    	// Isolate the force of gravity with low-pass filter.
    	gravity[0] = 0.8 * gravity[0] + (1 - 0.8) * x;
    	gravity[1] = 0.8 * gravity[1] + (1 - 0.8) * y;
    	gravity[2] = 0.8 * gravity[2] + (1 - 0.8) * z;
    	// Remove gravity contribution with high-pass filter
    	x = x - gravity[0];
    	y = y - gravity[1];
    	z = z - gravity[2];
    	double norm=tool.norm(x, y, z);
    	if(!initialed){
    		normFilter=norm;
    		//initialed=true;
    	}else{
    	    normFilter=alpha*norm+(1-alpha)*normFilter;
    	}
    	output=normFilter;
    	if (!initialed){
    	    output=normFilter;
    	    initialed=true;
    	}else{
    		output=(16*output+normFilter)/17;
    	}
    	int count=times%16;
    	window[count]=output;
    	max=window[0];
    	min=window[0];
    	for(int i=1;i<window.length;i++){
    		if(window[i]>max)
    		{
    			max=window[i];
    		}
    		if(window[i]<min)
    		{
    			min=window[i];
    		}
    	}
    	SL=K * Math.pow((max-min), 0.25);
    	times++;
	}
	public double getSL() {
		return SL;
	}
	public void setSL(double sL) {
		SL = sL;
	}
}
